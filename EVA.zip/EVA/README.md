########## Earned Value Analysis (EVA) ##########

Este app tem como objetivo fazer a análise do valor agregado de um projeto. Isso será possível com o input das variáveis VALOR PREVISTO (VP), VALOR AGREGADO (VA) e CUSTO REAL (CR).

Em seguida será retornado a VARIAÇÃO DE CUSTO (VC), VARIAÇÃO DE PROGRESSO (VPr), ÍNDICE DE DESEMPENHO DE CUSTO (IDC) e ÍNDICE DE DESEMPENHO DE PRAZO (IDP), além de, apresentar o status do projeto de acordo com os IDC e IDP.

Nota: esta é uma versão beta do software, onde, será desenvolvido versõs mais complexas e detalhadas do EVA.
